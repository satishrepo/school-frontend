import React, { useState, useLayoutEffect } from 'react';
import { StyleSheet, Text, View, FlatList, TouchableOpacity, SafeAreaView, Button } from 'react-native';


const Item = ({item, onPress, backgroundColor}) => {
    return (
        <TouchableOpacity 
            style={{
                backgroundColor, 
                padding: 20,
                paddingHorizontal: 30,
                borderRadius: 5,
                margin: 5
            }}
            onPress={onPress}
        >
            <Text style={styles.attBtn}>{item.title}</Text>
        </TouchableOpacity>
    )
}

const Attendance = ({navigation, route}) => {

    const DATA = [{title:1, status: 1}, {title:2, status: 1},{title:3, status: 1},{title:4, status: 1}];
    const [studentData, setStudentData] = useState(DATA)
    const [absentData, setAbsentData] = useState([])
    const {selectedClass, selectedDate} = route.params

    const onPress = (item, index) => { 
        item.status = !item.status
        let absent = [...absentData]
        if (absent.length && absent.indexOf(item.title) > -1) {
            absent.splice(absent.indexOf(item.title), 1)
        } else {
            absent.push(item.title)
        }
        let sData = [...studentData]
        sData[index].status = !sData[index].status;
        setStudentData(sData)
        setAbsentData(absent)
    }

    const renderItem = ({ item, index }) => { 
        const backgroundColor = absentData.indexOf(item.title) < 0 ? 'green' : 'red';
        return (
            <Item item={item} onPress={() => onPress(item, index)} backgroundColor={backgroundColor}/>
        )
    }

    const submitAttendance = () => {

    }

    return (
        <SafeAreaView>
            <FlatList
                data={studentData}
                renderItem={renderItem}
                keyExtractor={(item) => item.title.toString()}
                // extraData={selectedId}
                horizontal={true}
            />
            <Button 
                onPress={submitAttendance}
                title='Submit'
            />
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    attBtn: {
        fontSize: 14
    }
})

export default Attendance;