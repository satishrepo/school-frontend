import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

const Profile = props => {

    return (
        <Text>This is Profil page</Text>
    )
}

export default Profile;