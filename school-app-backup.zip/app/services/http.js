// import { axios } from 'axios'

const http = {
    get : (url, params) => {
    
        return new Promise((resolve, reject) =>(
            fetch(url, {
                method: 'post'
            })
            .then(response => response.json())
            .then(response => {
                resolve(response)
            }).catch((err) => {
                reject(err)
            })
        ))
    },
    
    post : (url, data) => {
    
        return new Promise((resolve, reject) =>(
            fetch(url, {
                method: 'post',
                body: JSON.stringify(data)
            })
            .then(response => response.json())
            .then(response => {
                resolve(response)
            }).catch((err) => {
                resolve(err)
                reject(err)
            })
        ))
    }
}

export default http;